
package primerparcialedg1_ago.dic2021;

/**
 *
 * @author Javier Nieto Merodio
 */
public class PrimerParcialEDG1_agoDic2021 {

    public PrimerParcialEDG1_agoDic2021() {
    }
    
    public static <T> boolean inverso(PilaADT<T> p1, PilaADT<T> p2){
        PilaADT<T> aux = new PilaA();
        PilaADT<T> aux2 = new PilaA();
        boolean resp = true;
        
        if (!p2.isEmpty())
            copiaPila(p2, aux);
       
        while ((!aux.isEmpty()) && (!p1.isEmpty()) && resp){
            if (aux.peek().equals(p1.peek())){
                p2.push(aux.pop());
                aux2.push(p1.pop());
            
            }
            else
                resp = false;
        }
        if (!aux.isEmpty()){
            while(!aux.isEmpty())
            p2.push(aux.pop());
        
        }
        if (!aux2.isEmpty()){
            while(!aux2.isEmpty())
            p1.push(aux.pop());
        
        }
        
        
        
        return resp;
         
    }
    
    private static <T> void copiaPila(PilaADT<T> origen, PilaADT<T> destino){
        while(!origen.isEmpty())
            destino.push(origen.pop());
    }

    
    public static void main(String[] args) {
        
        PilaA pila1 = new PilaA();
        PilaA pila2 = new PilaA();
        
        pila1.push(1);
        pila1.push(2);
        pila1.push(3);
        
        pila2.push(3);
        pila2.push(2);
        pila2.push(1);
        
        PrimerParcialEDG1_agoDic2021 prueba = new PrimerParcialEDG1_agoDic2021();
        System.out.println(prueba.inverso(pila1, pila2));
        
        
        
        
        
        
    }
    
}
