
package primerparcialedg1_ago.dic2021;

/**
 *
 * @author Javier Nieto Merodio
 */
public class PrimerParcialEDG1_agoDic2021 {

    public PrimerParcialEDG1_agoDic2021() {
        
    }
    
    
    public static <T> double sumaNumeros(PilaADT<T> p1){
        PilaADT<T> aux = new PilaA();
        PilaADT<T> aux2 = new PilaA();
        int cont = 0;
        double sumaD = 0;
        
        
        
        if (!p1.isEmpty()){
            while (!p1.isEmpty()){
                if (p1.peek() instanceof Integer){
                    aux2.push(p1.peek());
                    aux.push(p1.pop()); 
                    
                }
                else if(p1.peek() instanceof Double){
                    aux2.push(p1.peek());
                    aux.push(p1.pop());
                    cont++;
                }
                else
                    aux.push(p1.pop());
            
            } 
        }
        
        while(!aux.isEmpty())
            p1.push(aux.pop());
        
        try{
            
            if (cont == 0){
                while(!aux2.isEmpty())
                    sumaD +=  (Integer)aux2.pop();
                
 
            } else if (cont > 0){
                while (!aux2.isEmpty()){
                    if (aux2.peek() instanceof Integer){
                        sumaD +=  (Integer)aux2.pop();
                    }
                    else if (aux2.peek() instanceof Double){
                        sumaD +=  (Double)aux2.pop();
                    
                    }
                
                }       
                
            } else{
                while(!aux2.isEmpty())
                    aux2.pop();
                aux2.pop();
                aux2.pop();
                
            }
                
            
        }
        catch (Exception e){
            
        }
        return sumaD;
        
    }

    
    public static void main(String[] args) {
        PilaA pil = new PilaA();
        
        
        pil.push("r");
        
        PrimerParcialEDG1_agoDic2021 prueba = new PrimerParcialEDG1_agoDic2021();
        System.out.println(prueba.sumaNumeros(pil));
        
    }
    
}
